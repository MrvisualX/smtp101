import { motion } from "motion/react";
import { Utensils, Coffee, Wine, Home, Info, MapPin, Phone } from "lucide-react";
import { useState } from "react";

type MenuItem = {
  id: number;
  name: string;
  description: string;
  price: string;
  category: "food" | "drinks" | "specials";
  image?: string;
};

const MENU_ITEMS: MenuItem[] = [
  {
    id: 1,
    name: "Basanti Pulao + Mutton Kosha",
    description: "Traditional fragrant yellow rice served with slow-cooked spicy mutton, salad, papad, rasgulla, and 2 mocktails.",
    price: "₹800",
    category: "specials",
    image: "https://picsum.photos/seed/mutton/800/600"
  },
  {
    id: 2,
    name: "Basanti Pulao + Chicken Kosha",
    description: "Traditional fragrant yellow rice served with spicy chicken curry, salad, papad, rasgulla, and 2 mocktails.",
    price: "₹700",
    category: "specials",
    image: "https://picsum.photos/seed/chicken/800/600"
  },
  {
    id: 3,
    name: "Paneer Butter Masala",
    description: "Creamy tomato-based curry with soft paneer cubes and aromatic spices.",
    price: "₹350",
    category: "food",
    image: "https://picsum.photos/seed/paneer/800/600"
  },
  {
    id: 4,
    name: "Fresh Lime Soda",
    description: "Refreshing lime juice with soda, salt, and sugar.",
    price: "₹120",
    category: "drinks",
    image: "https://picsum.photos/seed/lime/800/600"
  },
  {
    id: 5,
    name: "Masala Chai",
    description: "Traditional Indian spiced tea brewed with milk and ginger.",
    price: "₹60",
    category: "drinks",
    image: "https://picsum.photos/seed/tea/800/600"
  }
];

export default function App() {
  const [activeCategory, setActiveCategory] = useState<"all" | "food" | "drinks" | "specials">("all");

  const filteredItems = activeCategory === "all" 
    ? MENU_ITEMS 
    : MENU_ITEMS.filter(item => item.category === activeCategory);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md sticky top-0 z-50 border-b border-stone-200">
        <div className="max-w-5xl mx-auto px-6 py-4 flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2"
          >
            <Utensils className="text-brand-olive w-8 h-8" />
            <h1 className="text-2xl font-bold tracking-tight text-stone-900">Mayapur Restaurant</h1>
          </motion.div>
          
          <nav className="hidden md:flex gap-8 text-sm uppercase tracking-widest font-sans font-semibold text-stone-500">
            <a href="#" className="hover:text-brand-olive transition-colors flex items-center gap-1"><Home size={14}/> Home</a>
            <a href="#" className="text-brand-olive flex items-center gap-1 border-b-2 border-brand-olive pb-1"><Utensils size={14}/> Menu</a>
            <a href="#" className="hover:text-brand-olive transition-colors flex items-center gap-1"><Info size={14}/> About</a>
          </nav>
        </div>
      </header>

      <main className="flex-grow max-w-5xl mx-auto px-6 py-12 w-full">
        {/* Welcome Section */}
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <span className="text-brand-olive uppercase tracking-[0.3em] text-xs font-sans font-bold mb-4 block">Welcome to Excellence</span>
          <h2 className="text-5xl md:text-7xl font-light mb-6 leading-tight">Authentic Flavors of <span className="italic">Mayapur</span></h2>
          <p className="text-stone-500 max-w-2xl mx-auto text-lg leading-relaxed">
            Experience the rich culinary heritage of Bengal with our carefully curated menu, featuring traditional recipes passed down through generations.
          </p>
        </motion.section>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {(["all", "specials", "food", "drinks"] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-6 py-2 rounded-full text-sm font-sans font-bold uppercase tracking-wider transition-all ${
                activeCategory === cat 
                  ? "bg-brand-olive text-white shadow-lg shadow-brand-olive/20" 
                  : "bg-white text-stone-500 hover:bg-stone-100 border border-stone-200"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Menu Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredItems.map((item, index) => (
            <motion.div
              layout
              key={item.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-[2rem] overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 border border-stone-100 group"
            >
              <div className="aspect-[4/3] overflow-hidden relative">
                <img 
                  src={item.image} 
                  alt={item.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                {item.category === 'specials' && (
                  <div className="absolute top-4 right-4 bg-brand-olive text-white text-[10px] uppercase tracking-widest font-bold px-3 py-1 rounded-full">
                    Chef's Special
                  </div>
                )}
              </div>
              <div className="p-8">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-2xl font-medium text-stone-900 leading-tight">{item.name}</h3>
                  <span className="text-xl font-sans font-light text-brand-olive">{item.price}</span>
                </div>
                <p className="text-stone-500 text-sm leading-relaxed mb-6">
                  {item.description}
                </p>
                <button className="w-full py-3 border border-stone-200 rounded-xl text-xs uppercase tracking-widest font-bold hover:bg-stone-900 hover:text-white transition-colors duration-300">
                  Order Now
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-stone-900 text-stone-400 py-16">
        <div className="max-w-5xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-12">
          <div>
            <div className="flex items-center gap-2 text-white mb-6">
              <Utensils className="w-6 h-6" />
              <span className="text-xl font-bold tracking-tight">Mayapur Restaurant</span>
            </div>
            <p className="text-sm leading-relaxed">
              Serving authentic Bengali cuisine with love and devotion in the heart of Mayapur.
            </p>
          </div>
          
          <div>
            <h4 className="text-white uppercase tracking-widest text-xs font-bold mb-6">Contact Us</h4>
            <div className="space-y-4 text-sm">
              <div className="flex items-center gap-3">
                <MapPin size={16} className="text-brand-olive" />
                <span>ISKCON Road, Mayapur, West Bengal</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone size={16} className="text-brand-olive" />
                <span>+91 98765 43210</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-white uppercase tracking-widest text-xs font-bold mb-6">Opening Hours</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Monday - Friday</span>
                <span>10:00 - 22:00</span>
              </div>
              <div className="flex justify-between">
                <span>Saturday - Sunday</span>
                <span>09:00 - 23:00</span>
              </div>
            </div>
          </div>
        </div>
        <div className="max-w-5xl mx-auto px-6 pt-12 mt-12 border-t border-white/10 text-center text-[10px] uppercase tracking-[0.2em]">
          © 2024 Mayapur Restaurant. All Rights Reserved.
        </div>
      </footer>
    </div>
  );
}
